package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;
@Service
public class FlightServiceImpl implements FlightService{
	private static final Logger l = LoggerFactory.getLogger(FlightService.class);
	@Autowired
	FlightRepository flightRepository;
	@Autowired
	AirlineRepository airlineRepository;
	@Autowired
	FlightConverter flightConverter;
	//for create flight in ServiceImpl
	@Override
	public FlightDTO saveFlight(Flight flight) {
		
		Flight fl=flightRepository.save(flight);
		l.info("Flight "+flight.toString()+ " added at "+new Date() );
		return flightConverter.convertToFlightDTO(fl);
		
	}
	//for assign flight to airline in ServiceImpl
	@Override
	public FlightDTO assignFlightToAirline(int flightId, int airlineId) {
		Flight flight=flightRepository.findById(flightId).get();
		Airline airline=airlineRepository.findById(airlineId).get();
		flight.setAirline(airline);
		Flight f=flightRepository.save(flight);
		l.info("Assigning Flight"+flight.getFlight_id()+ " to Airline "+airline.getAirlineName()+" at "+new Date());
		return flightConverter.convertToFlightDTO(f);
		
	}
	//for search flight by source and destination in ServiceImpl
	@Override
	public List<FlightDTO> searchFlight(String source, String destination) {
		List<Flight> flights=(List<Flight>) flightRepository.searchFlight(source,destination);
		l.info("Searching flight using destination and source at "+new Date());
		List<FlightDTO> fDto=new ArrayList<>();
		for(Flight f: flights)
		{
			fDto.add(flightConverter.convertToFlightDTO(f));
		}
		return fDto;
	}
	//for update Flight in ServiceImpl
	@Override
	public FlightDTO updateFlight(int id, Flight flight) {
		//we need to check wheather Flight with given exist in DB or not
		Flight existFlight=flightRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Flight", "id", id));
		//we will get data from client and set in existing Flight
		existFlight.setAvailableSeats(flight.getAvailableSeats());
		existFlight.setDate(flight.getDate());
		existFlight.setTime(flight.getTime());
		existFlight.setTotalSeats(flight.getTotalSeats());
		existFlight.setTravellerClass(flight.getTravellerClass());
		existFlight.setSource(flight.getSource());
		existFlight.setDestination(flight.getDestination());
		flightRepository.save(existFlight);
		l.info("Updating flight details of "+id+" at "+new Date());
		return flightConverter.convertToFlightDTO(existFlight);
	}
	//for fetch flight by Id in ServiceImpl
	@Override
	public FlightDTO getFlightById(int id) {
		Flight fl=flightRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Flight", "id", id));
		l.info("Flight with "+id +" is fetched at " + new java.util.Date());
		return flightConverter.convertToFlightDTO(fl);
	}
	//for delete flight by id in ServiceImpl
	@Override
	public String deleteFlightById(int id) {
		String msg=null;
		Optional<Flight> opPass=flightRepository.findById(id);
		if(opPass.isPresent())
		{
			flightRepository.deleteById(id);
			msg="record deleted successfully";
		}
		else {
			throw new ResourceNotFoundException("Flight", "id", id);
		}
		l.info("Deleting flight details of "+id+" at "+new Date());
		return msg;
		
	}

	

}
