package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Passenger;

@DataJpaTest
@AutoConfigureTestDatabase(replace= AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerTestRepository {
	@Autowired
	private PassengerRepository passengerRepository;
	@Test
	//@Rollback(value=false)
	@Order(1)
	void savePassengerTest()
	{
		Passenger passenger=Passenger.builder().name("Ram").email("ram@gmail.com").phno("9799635413").userName("ram").password("ram123").role("user").build();
	Passenger p=passengerRepository.save(passenger);
	assertThat(p.getName()).isEqualTo("Ram");
	}
	@Test
	@Order(3)
	void getAllPassengerTest()
	{
		List<Passenger> list=passengerRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
		
	}
	@Test
//	@Rollback(value=false)
	@Order(2)
	void updatePassengerTest()
	{
		Passenger expass= passengerRepository.findById(7).get();
		expass.setName("Chayan Jana");
		Passenger p=passengerRepository.save(expass);
		assertThat(p.getName()).isEqualTo("Chayan Jana");
		
	}
	@Test
	@Order(4)
	void deletePassengerTest()
	{
		passengerRepository.deleteById(5);
		assertThrows(NoSuchElementException.class,()->passengerRepository.findById(5).get());
//		Passenger pass= passengerRepository.findById(5).get();
//		assertNull(pass);
	}
	@Test
	@DisplayName("Negetive Test Case")
	@Order(5)
	void updatePassengerNegetiveTest()
	{
		Passenger expass= passengerRepository.findById(7).get();
		expass.setName("soumen");
		Passenger p=passengerRepository.save(expass);
		assertThat(p.getName()).isEqualTo("Chayan Jana");
		
	}
}
