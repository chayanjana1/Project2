package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.Airline;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AirlineRepositoryTest {

	@Autowired
	AirlineRepository airlineRepository;
	
	@Test
	@Order(1)
	void saveAirlineTest() {
		Airline airline = Airline.builder().airlineName("air india").fare(3300.37f).build();
		
		Airline a= airlineRepository.save(airline);
		assertEquals(a.getAirlineName(), "air india");
	}
	
	@Test
	@Order(3)
	void updateAirlineTest()
	{
		Airline airline = Airline.builder().airlineName("air india").fare(3300.37f).build();
		airline.setAirlineName("indigo");
		Airline a = airlineRepository.save(airline);
		assertEquals(a.getAirlineName(), "indigo");
	}
	
	@Test
	@Order(2)
	@DisplayName("Negative Test Case")
	void getAllAirlineTest()
	{
		List<Airline> air = airlineRepository.findAll();
		assertThat(air.size()).isLessThan(1);
	}
}
