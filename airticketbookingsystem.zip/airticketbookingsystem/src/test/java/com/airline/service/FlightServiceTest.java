package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Flight;
import com.airline.model.FlightDTO;
import com.airline.repository.FlightRepository;
import com.airline.util.FlightConverter;
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FlightServiceTest {
	@Autowired
	private FlightService flightService;
	
	@Autowired
	private FlightConverter flightConverter;
	
	@MockBean
	private FlightRepository flightRepository;
	
	//this method will test the saveFlight method
	
	@Test
	@Order(1)
	void testSaveFlight()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("durgapur").destination("pune").travellerClass("business").build();
		
		Mockito.when(flightRepository.save(flight)).thenReturn(flight);
		FlightDTO dto = flightConverter.convertToFlightDTO(flight); 
		assertEquals(dto.getFlight_id(), flight.getFlight_id());
	}
	@Test
	@Order(3)
	void testdeleteFlightById()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-13")).time("10:30").source("durgapur").
				destination("pune").travellerClass("business").build();
		
		Optional<Flight> opf= Optional.of(flight);
		Mockito.when(flightRepository.findById(opf.get().getFlight_id())).thenReturn(opf);
		
		assertThat(flightService.deleteFlightById(opf.get().getFlight_id())).isEqualTo("record deleted successfully");
		
	}
	@Test
	@Order(2)
	@DisplayName("Negative Test Case")
	void testupdateFlight()
	{
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-13")).time("10:30").source("durgapur").
				destination("pune").travellerClass("business").build();
		
		Optional<Flight> opfli= Optional.of(flight);
		Mockito.when(flightRepository.findById(flight.getFlight_id())).thenReturn(opfli);
		Flight p=opfli.get();
		flight.setAvailableSeats(10);
		
		Mockito.when(flightRepository.save(flight)).thenReturn(p);
		 
		 FlightDTO dto=flightService.updateFlight(flight.getFlight_id(), flight);
		assertEquals(dto.getAvailableSeats(), 5);
	}

}
